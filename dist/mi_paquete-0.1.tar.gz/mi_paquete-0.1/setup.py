from setuptools import setup, find_packages

setup(
    name="mi_paquete",
    version="0.1",
    packages=find_packages(),
    author="Nicolas",
    author_email="tu.email@example.com",
    description="Un paquete simple de gestión de clientes.",
    url="https://github.com/ndifabio92/coder-house-python",
)