# python

## Ejecutar Programa

Estar en la ruta principal y ejecutar el siguiente comando

> python main.py
